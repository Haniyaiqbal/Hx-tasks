from django.apps import AppConfig


class SliderTaskConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'slider_task'
